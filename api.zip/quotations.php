<?php
// api/quotations.php
require_once '../includes/auth.php';
require_once '../config/database.php';

checkAuth();
$user_id = $_SESSION['user_id'];
$business_id = getBusinessId();
$shop_id = getShopId();

header('Content-Type: application/json');

try {
    $method = $_SERVER['REQUEST_METHOD'];
    
    switch ($method) {
        case 'GET':
            getQuotations();
            break;
        case 'POST':
            createQuotation();
            break;
        case 'PUT':
            updateQuotation();
            break;
        case 'DELETE':
            deleteQuotation();
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

function createQuotation() {
    global $pdo, $user_id, $business_id, $shop_id;
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Generate quotation number
    $prefix = 'QTN';
    $yearMonth = date('Ym');
    $sequence = getNextSequenceNumber('quotation', $business_id);
    $quotation_number = sprintf("%s%s%04d", $prefix, $yearMonth, $sequence);
    
    $sql = "INSERT INTO quotations (
                quotation_number, business_id, shop_id, created_by,
                customer_name, customer_phone, customer_address, customer_gstin,
                quotation_date, valid_until, subtotal, total_discount,
                grand_total, notes, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', NOW())";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $quotation_number,
        $business_id,
        $shop_id,
        $user_id,
        $data['customer_name'],
        $data['customer_phone'] ?? '',
        $data['customer_address'] ?? '',
        $data['customer_gstin'] ?? '',
        $data['quotation_date'],
        $data['valid_until'],
        $data['subtotal'],
        $data['total_discount'],
        $data['grand_total'],
        $data['notes'] ?? ''
    ]);
    
    $quotation_id = $pdo->lastInsertId();
    
    // Insert quotation items
    $items_sql = "INSERT INTO quotation_items (
                    quotation_id, product_id, product_name, quantity,
                    unit, unit_price, price_type, discount_amount,
                    discount_type, total_price
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $pdo->prepare($items_sql);
    
    foreach ($data['items'] as $item) {
        $stmt->execute([
            $quotation_id,
            $item['id'],
            $item['name'],
            $item['quantity'],
            $item['unit'],
            $item['price'],
            $item['price_type'],
            $item['discount_value'] ?? 0,
            $item['discount_type'] ?? 'percentage',
            $item['total'] ?? 0
        ]);
    }
    
    echo json_encode([
        'success' => true,
        'quotation_id' => $quotation_id,
        'quotation_number' => $quotation_number
    ]);
}
?>